// Claude 中文翻译 - 后台脚本

// 默认设置
const DEFAULT_SETTINGS = {
  serverUrl: 'http://localhost:8000',
  model: 'claude-3-5-sonnet-20241022',
  targetLanguage: '简体中文'
};

// 创建右键菜单
browser.contextMenus.create({
  id: 'translate-to-chinese',
  title: '翻译成中文',
  contexts: ['selection']
});

browser.contextMenus.create({
  id: 'translate-to-english',
  title: 'Translate to English',
  contexts: ['selection']
});

browser.contextMenus.create({
  id: 'explain-text',
  title: '解释这段文字',
  contexts: ['selection']
});

// 获取设置
async function getSettings() {
  const result = await browser.storage.local.get('settings');
  return result.settings || DEFAULT_SETTINGS;
}

// 调用 Claude API
async function callClaudeAPI(prompt, settings) {
  const response = await fetch(`${settings.serverUrl}/v1/messages`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'x-api-key': 'sk-local-proxy-key',
      'anthropic-version': '2023-06-01'
    },
    body: JSON.stringify({
      model: settings.model,
      max_tokens: 4096,
      messages: [
        {
          role: 'user',
          content: prompt
        }
      ]
    })
  });
  
  if (!response.ok) {
    const errorText = await response.text();
    throw new Error(`API 请求失败: ${response.status} - ${errorText}`);
  }
  
  const data = await response.json();
  
  // 提取文本响应
  if (data.content && data.content.length > 0) {
    return data.content[0].text;
  }
  
  throw new Error('无法解析 API 响应');
}

// 处理菜单点击
browser.contextMenus.onClicked.addListener(async (info, tab) => {
  const selectedText = info.selectionText;
  if (!selectedText) return;
  
  const settings = await getSettings();
  let prompt = '';
  
  switch (info.menuItemId) {
    case 'translate-to-chinese':
      prompt = `请将以下文字翻译成${settings.targetLanguage}。只输出翻译结果，不要添加任何解释或说明。

原文：
${selectedText}`;
      break;
      
    case 'translate-to-english':
      prompt = `Please translate the following text to English. Only output the translation, no explanations.

Original text:
${selectedText}`;
      break;
      
    case 'explain-text':
      prompt = `请用简体中文解释以下内容，帮助理解其含义：

${selectedText}`;
      break;
      
    default:
      return;
  }
  
  // 发送开始翻译的消息
  browser.tabs.sendMessage(tab.id, {
    action: 'showLoading',
    type: info.menuItemId
  });
  
  try {
    const result = await callClaudeAPI(prompt, settings);
    
    // 发送翻译结果
    browser.tabs.sendMessage(tab.id, {
      action: 'showResult',
      result: result,
      originalText: selectedText,
      type: info.menuItemId
    });
  } catch (error) {
    browser.tabs.sendMessage(tab.id, {
      action: 'showError',
      error: error.message
    });
  }
});

// 处理快捷键
browser.commands.onCommand.addListener(async (command) => {
  // 获取当前活动标签页
  const tabs = await browser.tabs.query({ active: true, currentWindow: true });
  if (!tabs[0]) return;
  
  const tab = tabs[0];
  
  // 向内容脚本请求选中的文字
  try {
    const response = await browser.tabs.sendMessage(tab.id, {
      action: 'getSelectedText'
    });
    
    if (!response || !response.selectedText) {
      // 没有选中文字，不执行操作
      return;
    }
    
    const selectedText = response.selectedText;
    const settings = await getSettings();
    let prompt = '';
    let type = '';
    
    switch (command) {
      case 'translate-selection':
        type = 'translate-to-chinese';
        prompt = `请将以下文字翻译成${settings.targetLanguage}。只输出翻译结果，不要添加任何解释或说明。

原文：
${selectedText}`;
        break;
        
      case 'explain-selection':
        type = 'explain-text';
        prompt = `请用简体中文解释以下内容，帮助理解其含义：

${selectedText}`;
        break;
        
      default:
        return;
    }
    
    // 发送开始翻译的消息
    browser.tabs.sendMessage(tab.id, {
      action: 'showLoading',
      type: type
    });
    
    const result = await callClaudeAPI(prompt, settings);
    
    // 发送翻译结果
    browser.tabs.sendMessage(tab.id, {
      action: 'showResult',
      result: result,
      originalText: selectedText,
      type: type
    });
  } catch (error) {
    browser.tabs.sendMessage(tab.id, {
      action: 'showError',
      error: error.message || '快捷键执行失败'
    });
  }
});
