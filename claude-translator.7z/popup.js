// Claude 中文翻译 - 设置页面

const DEFAULT_SETTINGS = {
  serverUrl: 'http://localhost:8000',
  model: 'claude-3-5-sonnet-20241022',
  targetLanguage: '简体中文'
};

// 加载设置
async function loadSettings() {
  const result = await browser.storage.local.get('settings');
  const settings = result.settings || DEFAULT_SETTINGS;
  
  document.getElementById('serverUrl').value = settings.serverUrl;
  document.getElementById('model').value = settings.model;
  document.getElementById('targetLanguage').value = settings.targetLanguage;
}

// 保存设置
async function saveSettings(e) {
  e.preventDefault();
  
  const settings = {
    serverUrl: document.getElementById('serverUrl').value.trim() || DEFAULT_SETTINGS.serverUrl,
    model: document.getElementById('model').value,
    targetLanguage: document.getElementById('targetLanguage').value
  };
  
  // 移除末尾斜杠
  settings.serverUrl = settings.serverUrl.replace(/\/+$/, '');
  
  await browser.storage.local.set({ settings });
  
  showStatus('设置已保存！', 'success');
}

// 测试连接
async function testConnection() {
  const serverUrl = document.getElementById('serverUrl').value.trim() || DEFAULT_SETTINGS.serverUrl;
  
  showStatus('正在测试连接...', 'success');
  
  try {
    // 测试健康检查端点
    const healthResponse = await fetch(`${serverUrl}/health`, {
      method: 'GET'
    });
    
    if (!healthResponse.ok) {
      throw new Error(`服务器返回 ${healthResponse.status}`);
    }
    
    // 测试 API 调用
    const apiResponse = await fetch(`${serverUrl}/v1/messages`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': 'sk-local-proxy-key',
        'anthropic-version': '2023-06-01'
      },
      body: JSON.stringify({
        model: document.getElementById('model').value,
        max_tokens: 50,
        messages: [
          { role: 'user', content: '回复"连接成功"这四个字' }
        ]
      })
    });
    
    if (!apiResponse.ok) {
      const errorText = await apiResponse.text();
      throw new Error(`API 错误: ${errorText}`);
    }
    
    const data = await apiResponse.json();
    if (data.content && data.content[0]) {
      showStatus(`✓ 连接成功！响应: ${data.content[0].text.substring(0, 50)}`, 'success');
    } else {
      showStatus('✓ 连接成功！', 'success');
    }
  } catch (error) {
    showStatus(`✗ 连接失败: ${error.message}`, 'error');
  }
}

// 显示状态
function showStatus(message, type) {
  const status = document.getElementById('status');
  status.textContent = message;
  status.className = `status ${type}`;
}

// 初始化
document.addEventListener('DOMContentLoaded', loadSettings);
document.getElementById('settings-form').addEventListener('submit', saveSettings);
document.getElementById('test-btn').addEventListener('click', testConnection);
