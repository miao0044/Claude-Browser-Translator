// Claude 中文翻译 - 内容脚本

// 创建元素的辅助函数
function createElement(tag, className, textContent) {
  const el = document.createElement(tag);
  if (className) el.className = className;
  if (textContent) el.textContent = textContent;
  return el;
}

// 创建结果弹窗
function createPopup() {
  // 移除已存在的弹窗
  const existing = document.getElementById('claude-translator-popup');
  if (existing) existing.remove();
  
  const popup = document.createElement('div');
  popup.id = 'claude-translator-popup';
  
  // 创建 header
  const header = createElement('div', 'claude-translator-header');
  const title = createElement('span', 'claude-translator-title');
  const closeBtn = createElement('button', 'claude-translator-close', '×');
  closeBtn.title = '关闭';
  header.appendChild(title);
  header.appendChild(closeBtn);
  
  // 创建 content
  const content = createElement('div', 'claude-translator-content');
  
  const loading = createElement('div', 'claude-translator-loading');
  const spinner = createElement('div', 'claude-translator-spinner');
  const loadingText = createElement('span', null, '正在翻译...');
  loading.appendChild(spinner);
  loading.appendChild(loadingText);
  
  const result = createElement('div', 'claude-translator-result');
  result.style.display = 'none';
  
  const error = createElement('div', 'claude-translator-error');
  error.style.display = 'none';
  
  content.appendChild(loading);
  content.appendChild(result);
  content.appendChild(error);
  
  // 创建 actions
  const actions = createElement('div', 'claude-translator-actions');
  const copyBtn = createElement('button', 'claude-translator-copy', '📋 复制');
  copyBtn.title = '复制';
  actions.appendChild(copyBtn);
  
  // 组装 popup
  popup.appendChild(header);
  popup.appendChild(content);
  popup.appendChild(actions);
  
  document.body.appendChild(popup);
  
  // 关闭按钮
  closeBtn.addEventListener('click', () => {
    popup.remove();
  });
  
  // 复制按钮
  copyBtn.addEventListener('click', () => {
    navigator.clipboard.writeText(result.textContent).then(() => {
      copyBtn.textContent = '✓ 已复制';
      setTimeout(() => {
        copyBtn.textContent = '📋 复制';
      }, 2000);
    });
  });
  
  // 拖拽和调整大小的状态变量
  let isDragging = false;
  let isResizing = false;

  // ESC 关闭
  document.addEventListener('keydown', function closeOnEsc(e) {
    if (e.key === 'Escape') {
      popup.remove();
      document.removeEventListener('keydown', closeOnEsc);
    }
  });
  
  // 拖拽功能
  let startX, startY, startLeft, startTop;
  
  header.addEventListener('mousedown', (e) => {
    // 不要在点击关闭按钮时触发拖拽
    if (e.target.classList.contains('claude-translator-close')) return;
    
    isDragging = true;
    startX = e.clientX;
    startY = e.clientY;
    
    const rect = popup.getBoundingClientRect();
    startLeft = rect.left;
    startTop = rect.top;
    
    // 取消 right 属性，改用 left 和 width
    popup.style.right = 'auto';
    popup.style.left = startLeft + 'px';
    popup.style.width = rect.width + 'px';
    
    e.preventDefault();
  });
  
  document.addEventListener('mousemove', (e) => {
    if (!isDragging) return;
    
    const deltaX = e.clientX - startX;
    const deltaY = e.clientY - startY;
    
    let newLeft = startLeft + deltaX;
    let newTop = startTop + deltaY;
    
    // 限制不超出屏幕
    newLeft = Math.max(0, Math.min(newLeft, window.innerWidth - popup.offsetWidth));
    newTop = Math.max(0, Math.min(newTop, window.innerHeight - popup.offsetHeight));
    
    popup.style.left = newLeft + 'px';
    popup.style.top = newTop + 'px';
  });
  
  document.addEventListener('mouseup', () => {
    isDragging = false;
  });
  
  // 调整大小功能
  let resizeStartX, resizeStartY, resizeStartWidth, resizeStartHeight;
  
  popup.addEventListener('mousedown', (e) => {
    const rect = popup.getBoundingClientRect();
    const isInResizeZone = (e.clientX > rect.right - 16) && (e.clientY > rect.bottom - 16);
    
    if (isInResizeZone) {
      isResizing = true;
      resizeStartX = e.clientX;
      resizeStartY = e.clientY;
      resizeStartWidth = rect.width;
      resizeStartHeight = rect.height;
      
      // 取消 right 属性
      popup.style.right = 'auto';
      popup.style.width = rect.width + 'px';
      
      e.preventDefault();
      e.stopPropagation();
    }
  });
  
  document.addEventListener('mousemove', (e) => {
    if (!isResizing) return;
    
    const deltaX = e.clientX - resizeStartX;
    const deltaY = e.clientY - resizeStartY;
    
    const newWidth = Math.max(300, resizeStartWidth + deltaX);
    const newHeight = Math.max(150, resizeStartHeight + deltaY);
    
    popup.style.width = newWidth + 'px';
    popup.style.height = newHeight + 'px';
  });
  
  document.addEventListener('mouseup', () => {
    isResizing = false;
  });
  
  return popup;
}

// 显示加载状态
function showLoading(type) {
  createPopup();
}

// 显示结果
function showResult(result) {
  const popup = document.getElementById('claude-translator-popup');
  if (!popup) return;
  
  const loading = popup.querySelector('.claude-translator-loading');
  const resultEl = popup.querySelector('.claude-translator-result');
  
  loading.style.display = 'none';
  resultEl.style.display = 'block';
  resultEl.textContent = result;
}

// 显示错误
function showError(error) {
  const popup = document.getElementById('claude-translator-popup');
  if (!popup) return;
  
  const loading = popup.querySelector('.claude-translator-loading');
  const errorEl = popup.querySelector('.claude-translator-error');
  
  loading.style.display = 'none';
  errorEl.style.display = 'block';
  
  // 清空并使用DOM方法添加内容
  errorEl.textContent = '';
  
  const strong = document.createElement('strong');
  strong.textContent = '错误';
  errorEl.appendChild(strong);
  
  errorEl.appendChild(document.createElement('br'));
  errorEl.appendChild(document.createTextNode(error));
  errorEl.appendChild(document.createElement('br'));
  errorEl.appendChild(document.createElement('br'));
  
  const small = document.createElement('small');
  small.textContent = '请确保 LiteLLM 代理服务器正在运行';
  errorEl.appendChild(small);
}

// 监听来自后台脚本的消息
browser.runtime.onMessage.addListener((message, sender, sendResponse) => {
  switch (message.action) {
    case 'showLoading':
      showLoading(message.type);
      break;
    case 'showResult':
      showResult(message.result);
      break;
    case 'showError':
      showError(message.error);
      break;
    case 'getSelectedText':
      // 返回当前选中的文字
      const selectedText = window.getSelection().toString().trim();
      sendResponse({ selectedText: selectedText });
      return true; // 表示我们会异步发送响应
  }
});
